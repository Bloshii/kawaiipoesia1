# kawaiipoema1.final

A Pen created on CodePen.io. Original URL: [https://codepen.io/Bloshii/pen/NPKzZJg](https://codepen.io/Bloshii/pen/NPKzZJg).

